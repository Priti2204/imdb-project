# IMDB-clone
IMDB clone is a database platform that helps you provide seamless services to entertainment lovers and critics.
With powerful TV shows, movies, and other categories databases it becomes easier for you to launch your own 
platform for ratings and reviews in the entertainment and media industry.
 
You can view project <a href="https://nitnawarerutika.github.io/IMDB-clone/"> here </a>.

# Here is some snapshots of my project -



![imdb1](https://user-images.githubusercontent.com/130966188/233561434-ba3e45b3-a341-42ad-83be-fe4347378227.PNG)
![imdb2](https://user-images.githubusercontent.com/130966188/233561448-5ea9f7a8-953f-4275-9528-3bb4a40443a5.PNG)
![imdb3](https://user-images.githubusercontent.com/130966188/233561469-e0251aab-9cf5-4b50-a6cc-6ff08baf5bbf.PNG)
